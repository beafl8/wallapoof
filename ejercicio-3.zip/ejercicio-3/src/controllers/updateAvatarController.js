import getPool from '../db/getPool.js';
import generateErrorUtil from '../utils/generateErrorUtil.js';
import { savePhotoUtil } from '../utils/savePhotoUtil.js';
// import {removePhotoUtil} from '../utils/removePhotoUtil.js';

const updateAvatarController = async (req, res, next) => {
    try {
        const 
    } catch (err) {
        next(err);
    }
};
export { updateAvatarController };
